# CZ云盘 Android 原生客户端

对接 https://cz.xcor.top/ （MXH 网盘系统）的原生 Android 应用。
**非网页打包**，Kotlin + Jetpack Compose 原生开发，iOS 纯白液态玻璃设计风格。

## 功能

- ✅ 账号密码登录（对接 /api/auth.php，Session Cookie 持久化）
- ✅ 首页存储概览（已用空间、文件数、分享数、VIP 等级）
- ✅ 文件管理（目录浏览、新建文件夹、上传、分享、下载、删除）
- ✅ 我的分享（列表、复制链接、取消分享）
- ✅ 回收站（恢复、彻底删除、清空）
- ✅ 分片上传（2MB 分片，支持大文件）
- ✅ iOS 液态玻璃 UI（白色半透明卡片、高光渐变、细描边）

## 目录结构

```
app/src/main/java/com/cz/cloud/
├── MainActivity.kt          # 入口 + 登录态判断
├── api/ApiClient.kt         # OkHttp 客户端（CookieJar 会话管理）
├── data/
│   ├── Models.kt            # 数据模型
│   ├── CloudRepository.kt   # 业务接口封装
│   └── SessionManager.kt    # Cookie 持久化
└── ui/
    ├── theme/               # 液态玻璃主题
    └── screens/             # 各页面
```

## 构建方式

### 方式一：GitHub Actions（推荐，无需本地环境）
1. 把本项目推到 GitHub 仓库
2. Actions 会自动构建，在 Artifacts 下载 APK

### 方式二：本地构建
```bash
./gradlew assembleDebug
# APK 位于 app/build/outputs/apk/debug/
```

## 服务端接口

基于 MXH 网盘系统 1.8.0 源码分析：
- POST /api/auth.php  (login / code_login / send_code / register / reset_password)
- GET  /api/files.php?action=list&folder_id=N
- POST /api/files.php (rename / move / delete)
- GET  /api/folders.php?action=tree / POST (create / rename / delete)
- POST /api/shares.php (list / create / delete)
- GET  /api/recycle.php?action=list / POST (restore / delete / clear)
- POST /api/upload_chunk.php (init / chunk / merge)
