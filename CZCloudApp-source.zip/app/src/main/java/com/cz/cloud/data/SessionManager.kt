package com.cz.cloud.data

import android.content.Context
import android.util.Log
import com.cz.cloud.api.ApiClient
import okhttp3.Cookie

/**
 * 会话管理：Cookie 持久化 + 登录状态判断
 * PHP Session 的 PHPSESSID 存 SharedPreferences，重启 App 不掉线
 */
object SessionManager {
    private const val TAG = "SessionManager"
    private const val PREFS = "cz_cloud_session"
    private const val KEY_COOKIES = "cookies"
    private const val KEY_USER = "user_json"
    private const val KEY_LAST_CHECK = "last_check"

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
        restoreCookies()
    }

    private fun restoreCookies() {
        try {
            val ctx = appContext ?: return
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val raw = prefs.getString(KEY_COOKIES, null) ?: return
            val cookies = raw.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
                try {
                    val parts = line.split("|")
                    if (parts.size < 2) return@mapNotNull null
                    Cookie.Builder()
                        .name(parts[0])
                        .value(parts[1])
                        .domain("cz.xcor.top")
                        .path("/")
                        .build()
                } catch (e: Exception) { null }
            }
            if (cookies.isNotEmpty()) ApiClient.restoreCookies(cookies)
        } catch (e: Exception) {
            Log.w(TAG, "restore cookies failed", e)
        }
    }

    fun persistCookies() {
        try {
            val ctx = appContext ?: return
            val cookies = ApiClient.exportCookies()
            val raw = cookies.joinToString("\n") { "${it.name}|${it.value}" }
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_COOKIES, raw).apply()
        } catch (e: Exception) {
            Log.w(TAG, "persist cookies failed", e)
        }
    }

    /** 保存登录用户信息 */
    fun saveUser(user: UserInfo) {
        val ctx = appContext ?: return
        val json = org.json.JSONObject().apply {
            put("id", user.id)
            put("username", user.username)
            put("email", user.email)
            put("nickname", user.nickname)
            put("avatar", user.avatar)
            put("storage_used", user.storageUsed)
            put("storage_limit", user.storageLimit)
            put("vip_level", user.vipLevel)
            put("vip_expire", user.vipExpire)
            put("balance", user.balance)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_USER, json.toString()).apply()
    }

    /** 读取缓存用户（不发起网络） */
    fun cachedUser(): UserInfo? {
        val ctx = appContext ?: return null
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_USER, null) ?: return null
        return try { UserInfo.fromJson(org.json.JSONObject(raw)) } catch (e: Exception) { null }
    }

    fun clearSession() {
        val ctx = appContext ?: return
        ApiClient.clearCookies()
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** 验证会话是否有效：请求 files.php?action=list，成功即已登录 */
    suspend fun checkSessionValid(): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val r = ApiClient.getJson("/api/files.php?action=list&folder_id=0")
        r is ApiClient.ApiResult.Success
    }
}
