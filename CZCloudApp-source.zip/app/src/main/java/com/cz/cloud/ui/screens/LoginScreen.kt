package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.CloudRepository
import com.cz.cloud.data.SessionManager
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.launch

/**
 * 登录页：iOS 液态玻璃风格
 * 支持账号密码登录，带滑块人机验证占位
 */
@Composable
fun LoginScreen(onLoginSuccess: () -> Unit) {
    val repo = remember { CloudRepository.get() }
    val scope = rememberCoroutineScope()

    var account by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(96.dp))

        // Logo 区域
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    brush = Brush.verticalGradient(
                        listOf(AccentBlue, Color(0xFF5AC8FA))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("☁", fontSize = 44.sp, color = Color.White)
        }
        Spacer(Modifier.height(24.dp))

        Text(
            "CZ 云盘",
            style = MaterialTheme.typography.displayMedium,
            color = InkBlack
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "登录以管理你的云端文件",
            style = MaterialTheme.typography.bodyMedium,
            color = InkGray
        )

        Spacer(Modifier.height(40.dp))

        // 玻璃卡片表单
        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
            Column(Modifier.padding(24.dp)) {
                // 账号输入
                Text("账号", style = MaterialTheme.typography.labelMedium, color = InkGray)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = account,
                    onValueChange = { account = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("用户名 / 邮箱", color = InkGrayLight) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = GlassStroke,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                Spacer(Modifier.height(16.dp))

                // 密码输入
                Text("密码", style = MaterialTheme.typography.labelMedium, color = InkGray)
                Spacer(Modifier.height(6.dp))
                var showPwd by remember { mutableStateOf(false) }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("请输入密码", color = InkGrayLight) },
                    singleLine = true,
                    visualTransformation = if (showPwd) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(onClick = { showPwd = !showPwd }) {
                            Text(if (showPwd) "隐藏" else "显示", color = AccentBlue, style = MaterialTheme.typography.labelMedium)
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = GlassStroke,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                Spacer(Modifier.height(12.dp))

                // 记住登录
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = rememberMe,
                        onCheckedChange = { rememberMe = it },
                        colors = CheckboxDefaults.colors(checkedColor = AccentBlue)
                    )
                    Text("记住登录（3 天内免重复登录）", style = MaterialTheme.typography.bodySmall, color = InkGray)
                }

                if (errorMsg.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        errorMsg,
                        color = DangerRed,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(Modifier.height(20.dp))

                // 登录按钮
                Button(
                    onClick = {
                        loading = true
                        errorMsg = ""
                        scope.launch {
                            val r = repo.login(account.trim(), password, rememberMe, "")
                            loading = false
                            when (r) {
                                is ApiClient.ApiResult.Success -> {
                                    SessionManager.persistCookies()
                                    onLoginSuccess()
                                }
                                is ApiClient.ApiResult.Failure -> errorMsg = r.message
                            }
                        }
                    },
                    enabled = !loading && account.isNotBlank() && password.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentBlue,
                        disabledContainerColor = AccentBlue.copy(alpha = 0.4f)
                    )
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Text("登 录", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "如需注册或找回密码，请访问网页版 cz.xcor.top",
            style = MaterialTheme.typography.bodySmall,
            color = InkGrayLight,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
    }
}
