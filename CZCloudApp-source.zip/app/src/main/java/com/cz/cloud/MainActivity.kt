package com.cz.cloud

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cz.cloud.data.SessionManager
import com.cz.cloud.ui.screens.FilesScreen
import com.cz.cloud.ui.screens.HomeScreen
import com.cz.cloud.ui.screens.LoginScreen
import com.cz.cloud.ui.screens.ProfileScreen
import com.cz.cloud.ui.screens.RecycleScreen
import com.cz.cloud.ui.screens.SharesScreen
import com.cz.cloud.ui.screens.UploadScreen
import com.cz.cloud.ui.theme.CZCloudTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionManager.init(this)
        enableEdgeToEdge()
        setContent {
            CZCloudTheme {
                val nav = rememberNavController()
                var loggedIn by remember { mutableStateOf<Boolean?>(null) }

                LaunchedEffect(Unit) {
                    loggedIn = SessionManager.checkSessionValid()
                }

                when (val state = loggedIn) {
                    null -> LaunchSplash()
                    true -> MainScaffold(nav)
                    false -> LoginScreen(onLoginSuccess = {
                        loggedIn = true
                    })
                }
            }
        }
    }
}

@Composable
fun LaunchSplash() {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {}
}
