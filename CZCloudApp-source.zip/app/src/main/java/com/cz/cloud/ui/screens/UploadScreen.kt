package com.cz.cloud.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.CloudRepository
import com.cz.cloud.data.Formatters
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import androidx.compose.foundation.clickable

@Composable
fun UploadScreen(nav: NavHostController, folderId: Int = 0) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { CloudRepository.get() }
    val snackbar = remember { SnackbarHostState() }

    // 待上传列表：uri -> (name, size)
    val picked = remember { mutableStateListOf<Pair<Uri, Pair<String, Long>>>() }
    var uploading by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) {
            scope.launch(Dispatchers.IO) {
                try {
                    val name = queryName(context, u)
                    val size = querySize(context, u)
                    withContext(Dispatchers.Main) { picked.add(u to (name to size)) }
                } catch (e: Exception) { }
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Text("✕", fontSize = 20.sp, color = InkBlack)
            }
            Text("上传文件", style = MaterialTheme.typography.headlineMedium, color = InkBlack)
        }
        Spacer(Modifier.height(8.dp))

        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
            Column(
                Modifier.fillMaxWidth().clickable {
                    picker.launch(arrayOf("*/*"))
                }.padding(40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("⬆", fontSize = 40.sp, color = AccentBlue)
                Spacer(Modifier.height(8.dp))
                Text("点击选择文件", style = MaterialTheme.typography.titleSmall, color = InkBlack)
                Text("支持任意类型", style = MaterialTheme.typography.bodySmall, color = InkGray)
            }
        }

        Spacer(Modifier.height(20.dp))
        if (picked.isNotEmpty()) {
            Text("已选 ${picked.size} 个文件", style = MaterialTheme.typography.titleSmall, color = InkBlack)
            Spacer(Modifier.height(10.dp))
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            picked.forEachIndexed { idx, pair ->
                val (uri, meta) = pair
                GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 14.dp) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(meta.first, style = MaterialTheme.typography.bodyMedium, color = InkBlack, maxLines = 1)
                            Text(Formatters.size(meta.second), style = MaterialTheme.typography.bodySmall, color = InkGray)
                        }
                        IconButton(onClick = { picked.removeAt(idx) }) {
                            Icon(Icons.Filled.Close, null, tint = InkGray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        if (progressText.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text(progressText, style = MaterialTheme.typography.bodySmall, color = AccentBlue)
        }

        Spacer(Modifier.weight(1f))

        Button(
            onClick = {
                uploading = true
                scope.launch(Dispatchers.IO) {
                    val total = picked.size
                    var done = 0
                    for ((uri, meta) in picked.toList()) {
                        withContext(Dispatchers.Main) {
                            progressText = "上传中 (${done + 1}/$total)：${meta.first}"
                        }
                        val ok = uploadSingle(context, uri, meta.first, meta.second, folderId)
                        if (ok) {
                            done++
                            withContext(Dispatchers.Main) { picked.remove(uri) }
                        }
                    }
                    withContext(Dispatchers.Main) {
                        uploading = false
                        progressText = "完成：成功 $done/$total"
                        snackbar.showSnackbar("上传完成")
                    }
                }
            },
            enabled = !uploading && picked.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
        ) {
            Text(if (uploading) "上传中…" else "开始上传", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(20.dp))
    }
}

/** 单文件分片上传 */
private suspend fun uploadSingle(
    context: android.content.Context, uri: Uri, name: String, size: Long, folderId: Int
): Boolean = withContext(Dispatchers.IO) {
    try {
        val chunkSize = 2 * 1024 * 1024  // 2MB
        val chunks = ((size + chunkSize - 1) / chunkSize).toInt().coerceAtLeast(1)

        val initR = CloudRepository.get().uploadInit(name, size, chunks, chunkSize, folderId)
        if (initR !is ApiClient.ApiResult.Success) return@withContext false
        val uploadId = initR.json.optJSONObject("data")?.optString("upload_id") ?: return@withContext false

        // 拷贝到缓存目录
        val cacheFile = File(context.cacheDir, "up_${System.currentTimeMillis()}")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(cacheFile).use { output -> input.copyTo(output) }
        }

        // 逐片上传
        val chunkFile = File(context.cacheDir, "chunk_tmp")
        for (i in 0 until chunks) {
            val offset = i.toLong() * chunkSize
            val len = minOf(chunkSize.toLong(), size - offset).toInt()
            FileOutputStream(chunkFile).use { out ->
                java.io.RandomAccessFile(cacheFile, "r").use { raf ->
                    raf.seek(offset)
                    val buf = ByteArray(len)
                    raf.readFully(buf)
                    out.write(buf)
                }
            }
            val r = ApiClient.uploadChunk(uploadId, i, offset, chunkFile)
            if (r !is ApiClient.ApiResult.Success) {
                cacheFile.delete(); chunkFile.delete()
                return@withContext false
            }
        }
        chunkFile.delete()

        val mergeR = CloudRepository.get().uploadMerge(uploadId)
        cacheFile.delete()
        mergeR is ApiClient.ApiResult.Success
    } catch (e: Exception) {
        false
    }
}

private fun queryName(context: android.content.Context, uri: Uri): String {
    return context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && idx >= 0) c.getString(idx) else "file"
    } ?: "file"
}

private fun querySize(context: android.content.Context, uri: Uri): Long {
    return context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
        if (c.moveToFirst() && idx >= 0) c.getLong(idx) else 0L
    } ?: 0L
}
