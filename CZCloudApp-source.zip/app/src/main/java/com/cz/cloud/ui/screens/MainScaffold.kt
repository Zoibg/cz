package com.cz.cloud.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState

sealed class Dest(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Dest("home", "首页", Icons.Filled.Home)
    data object Files : Dest("files", "文件", Icons.Filled.Folder)
    data object Shares : Dest("shares", "分享", Icons.Filled.Share)
    data object Recycle : Dest("recycle", "回收站", Icons.Filled.Delete)
    data object Profile : Dest("profile", "我的", Icons.Filled.Person)

    companion object {
        val bottomNav = listOf(Home, Files, Shares, Recycle, Profile)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(nav: NavHostController) {
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = Dest.bottomNav.any { it.route == currentRoute }
    var fabVisibleRoute by remember { mutableStateOf("files") }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    Dest.bottomNav.forEach { dest ->
                        NavigationBarItem(
                            selected = currentRoute == dest.route,
                            onClick = {
                                nav.navigate(dest.route) {
                                    popUpTo(Dest.Home.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") { HomeScreen(nav) }
            composable("files") { FilesScreen(nav) }
            composable("files/{folderId}") { entry ->
                val folderId = entry.arguments?.getString("folderId")?.toIntOrNull() ?: 0
                FilesScreen(nav, folderId)
            }
            composable("shares") { SharesScreen(nav) }
            composable("recycle") { RecycleScreen(nav) }
            composable("profile") { ProfileScreen(nav) }
            composable("upload/{folderId}") { entry ->
                val folderId = entry.arguments?.getString("folderId")?.toIntOrNull() ?: 0
                UploadScreen(nav, folderId)
            }
        }
    }
}
