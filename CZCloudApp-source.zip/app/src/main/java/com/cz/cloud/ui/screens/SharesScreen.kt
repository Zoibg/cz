package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.CloudRepository
import com.cz.cloud.data.CloudShare
import com.cz.cloud.data.Formatters
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SharesScreen(nav: NavHostController) {
    val scope = rememberCoroutineScope()
    val repo = remember { CloudRepository.get() }
    val snackbar = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current

    var shares by remember { mutableStateOf(listOf<CloudShare>()) }
    var loading by remember { mutableStateOf(true) }
    var actionShare by remember { mutableStateOf<CloudShare?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            when (val r = repo.listShares()) {
                is ApiClient.ApiResult.Success -> {
                    val arr = r.json.optJSONArray("data")
                    val list = mutableListOf<CloudShare>()
                    if (arr != null) for (i in 0 until arr.length()) list.add(CloudShare.fromJson(arr.getJSONObject(i)))
                    shares = list
                }
                is ApiClient.ApiResult.Failure -> snackbar.showSnackbar(r.message)
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Text(
                "我的分享",
                style = MaterialTheme.typography.headlineMedium,
                color = InkBlack,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )

            if (loading) {
                Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AccentBlue)
                }
            } else if (shares.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🔗", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("还没有分享", color = InkGray, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shares, key = { it.id }) { share ->
                        ShareRow(share,
                            onClick = { actionShare = share },
                            onCopy = {
                                clipboard.setText(AnnotatedString(share.shareUrl))
                                snackbar.showSnackbar("链接已复制")
                            }
                        )
                    }
                }
            }
        }
    }

    actionShare?.let { share ->
        ModalBottomSheet(
            onDismissRequest = { actionShare = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                Text(share.fileName, style = MaterialTheme.typography.titleMedium, color = InkBlack)
                Text("分享码: ${share.shareCode}", style = MaterialTheme.typography.bodySmall, color = InkGray)
                if (share.password.isNotEmpty()) {
                    Text("提取码: ${share.password}", style = MaterialTheme.typography.bodySmall, color = InkGray)
                }
                Spacer(Modifier.height(18.dp))
                SheetAction(Icons.Filled.Link, "复制分享链接", AccentBlue) {
                    actionShare = null
                    clipboard.setText(AnnotatedString(share.shareUrl))
                    snackbar.showSnackbar("链接已复制")
                }
                SheetAction(Icons.Filled.Delete, "取消分享", DangerRed) {
                    actionShare = null
                    scope.launch {
                        when (repo.deleteShare(share.id)) {
                            is ApiClient.ApiResult.Success -> {
                                snackbar.showSnackbar("已取消分享")
                                refresh()
                            }
                            is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("删除失败")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShareRow(share: CloudShare, onClick: () -> Unit, onCopy: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), cornerRadius = 18.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Formatters.fileTypeIcon(share.fileType), fontSize = 20.sp)
                Spacer(Modifier.width(10.dp))
                Text(share.fileName, style = MaterialTheme.typography.titleSmall, color = InkBlack,
                     maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Text(share.shareUrl, style = MaterialTheme.typography.bodySmall, color = AccentBlue,
                 maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${share.downloadCount} 次下载", style = MaterialTheme.typography.bodySmall, color = InkGray)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onCopy, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("复制", color = AccentBlue, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
