package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.CloudRepository
import com.cz.cloud.data.Formatters
import com.cz.cloud.data.RecycleItem
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecycleScreen(nav: NavHostController) {
    val scope = rememberCoroutineScope()
    val repo = remember { CloudRepository.get() }
    val snackbar = remember { SnackbarHostState() }

    var items by remember { mutableStateOf(listOf<RecycleItem>()) }
    var loading by remember { mutableStateOf(true) }

    fun refresh() {
        scope.launch {
            loading = true
            when (val r = repo.recycleList()) {
                is ApiClient.ApiResult.Success -> {
                    val arr = r.json.optJSONArray("data")
                    val list = mutableListOf<RecycleItem>()
                    if (arr != null) for (i in 0 until arr.length()) list.add(RecycleItem.fromJson(arr.getJSONObject(i)))
                    items = list
                }
                is ApiClient.ApiResult.Failure -> snackbar.showSnackbar(r.message)
            }
            loading = false
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("回收站", style = MaterialTheme.typography.headlineMedium, color = InkBlack, modifier = Modifier.weight(1f))
                if (items.isNotEmpty()) {
                    TextButton(onClick = {
                        scope.launch {
                            when (repo.recycleClear()) {
                                is ApiClient.ApiResult.Success -> { snackbar.showSnackbar("已清空"); refresh() }
                                is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("清空失败")
                            }
                        }
                    }) { Text("清空", color = DangerRed) }
                }
            }

            if (loading) {
                Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AccentBlue)
                }
            } else if (items.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🗑", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("回收站为空", color = InkGray, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items, key = { it.id }) { item ->
                        RecycleRow(item,
                            onRestore = {
                                scope.launch {
                                    when (repo.recycleRestore(item.id)) {
                                        is ApiClient.ApiResult.Success -> { snackbar.showSnackbar("已恢复"); refresh() }
                                        is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("恢复失败")
                                    }
                                }
                            },
                            onDelete = {
                                scope.launch {
                                    when (repo.recycleDelete(item.id)) {
                                        is ApiClient.ApiResult.Success -> { snackbar.showSnackbar("已彻底删除"); refresh() }
                                        is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("删除失败")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecycleRow(item: RecycleItem, onRestore: () -> Unit, onDelete: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 18.dp) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(Formatters.fileTypeIcon(item.type), fontSize = 20.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.titleSmall, color = InkBlack, maxLines = 1)
                Text(Formatters.size(item.size), style = MaterialTheme.typography.bodySmall, color = InkGray)
            }
            TextButton(onClick = onRestore) { Text("恢复", color = SuccessGreen) }
            TextButton(onClick = onDelete) { Text("删除", color = DangerRed) }
        }
    }
}
