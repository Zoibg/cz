package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.CloudFile
import com.cz.cloud.data.CloudFolder
import com.cz.cloud.data.CloudRepository
import com.cz.cloud.data.Formatters
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.launch
import android.content.Intent
import android.net.Uri

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(nav: NavHostController, folderId: Int = 0) {
    val scope = rememberCoroutineScope()
    val repo = remember { CloudRepository.get() }
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current

    var folders by remember { mutableStateOf(listOf<CloudFolder>()) }
    var files by remember { mutableStateOf(listOf<CloudFile>()) }
    var loading by remember { mutableStateOf(true) }

    var actionFile by remember { mutableStateOf<CloudFile?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var showShareDialog by remember { mutableStateOf(false) }
    var shareFileName by remember { mutableStateOf("") }
    var shareFileId by remember { mutableStateOf(0) }

    fun refresh() {
        scope.launch {
            loading = true
            when (val r = repo.listFiles(folderId)) {
                is ApiClient.ApiResult.Success -> {
                    val d = r.json.optJSONObject("data")
                    val fArr = d?.optJSONArray("folders")
                    val fileArr = d?.optJSONArray("files")
                    val fl = mutableListOf<CloudFolder>()
                    if (fArr != null) for (i in 0 until fArr.length()) fl.add(CloudFolder.fromJson(fArr.getJSONObject(i)))
                    val fs = mutableListOf<CloudFile>()
                    if (fileArr != null) for (i in 0 until fileArr.length()) fs.add(CloudFile.fromJson(fileArr.getJSONObject(i)))
                    folders = fl
                    files = fs
                }
                is ApiClient.ApiResult.Failure -> snackbar.showSnackbar(r.message)
            }
            loading = false
        }
    }

    LaunchedEffect(folderId) { refresh() }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color.Transparent,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate("upload/$folderId") },
                containerColor = AccentBlue,
                contentColor = Color.White,
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("上传", fontWeight = FontWeight.SemiBold)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (folderId != 0) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AccentBlue)
                    }
                }
                Text(
                    if (folderId == 0) "我的文件" else "文件夹",
                    style = MaterialTheme.typography.headlineMedium,
                    color = InkBlack,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { showNewFolder = true }) {
                    Icon(Icons.Filled.CreateNewFolder, null, tint = AccentBlue, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("新建文件夹", color = AccentBlue)
                }
            }

            if (loading) {
                Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AccentBlue)
                }
            } else if (folders.isEmpty() && files.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📂", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("此目录为空", color = InkGray, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(folders, key = { "f${it.id}" }) { folder ->
                        FolderRow(folder) { nav.navigate("files/${folder.id}") }
                    }
                    items(files, key = { "d${it.id}" }) { file ->
                        FileRow(file) { actionFile = file }
                    }
                }
            }
        }
    }

    // 新建文件夹弹窗
    if (showNewFolder) {
        AlertDialog(
            onDismissRequest = { showNewFolder = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(24.dp),
            title = { Text("新建文件夹", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    placeholder = { Text("文件夹名称") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = GlassStroke
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            when (repo.createFolder(newFolderName.trim(), folderId)) {
                                is ApiClient.ApiResult.Success -> {
                                    showNewFolder = false
                                    newFolderName = ""
                                    refresh()
                                }
                                is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("创建失败")
                            }
                        }
                    },
                    enabled = newFolderName.isNotBlank()
                ) { Text("创建", color = AccentBlue, fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolder = false }) { Text("取消", color = InkGray) }
            }
        )
    }

    // 文件操作底部弹窗
    actionFile?.let { file ->
        ModalBottomSheet(
            onDismissRequest = { actionFile = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
                Text(file.name, style = MaterialTheme.typography.titleMedium, color = InkBlack,
                     maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${Formatters.size(file.size)} · ${file.downloadCount} 次下载",
                    style = MaterialTheme.typography.bodySmall, color = InkGray
                )
                Spacer(Modifier.height(18.dp))

                SheetAction(Icons.Filled.Link, "创建分享链接", AccentBlue) {
                    actionFile = null
                    shareFileId = file.id
                    shareFileName = file.name
                    showShareDialog = true
                }
                SheetAction(Icons.Filled.Download, "用浏览器下载", SuccessGreen) {
                    actionFile = null
                    val url = if (file.downloadUrl.startsWith("http")) file.downloadUrl
                              else "${ApiClient.BASE_URL}${file.downloadUrl}"
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        context.startActivity(intent)
                    } catch (e: Exception) { }
                }
                SheetAction(Icons.Filled.Delete, "删除（进回收站）", DangerRed) {
                    actionFile = null
                    scope.launch {
                        when (repo.deleteFile(file.id)) {
                            is ApiClient.ApiResult.Success -> {
                                snackbar.showSnackbar("已移至回收站")
                                refresh()
                            }
                            is ApiClient.ApiResult.Failure -> snackbar.showSnackbar("删除失败")
                        }
                    }
                }
            }
        }
    }

    // 创建分享弹窗
    if (showShareDialog) {
        ShareCreateDialog(
            fileName = shareFileName,
            onDismiss = { showShareDialog = false },
            onConfirm = { expireHours, downloadLimit, password ->
                scope.launch {
                    when (val r = repo.createShare(shareFileId, expireHours = expireHours, downloadLimit = downloadLimit, password = password)) {
                        is ApiClient.ApiResult.Success -> {
                            showShareDialog = false
                            snackbar.showSnackbar("分享创建成功")
                            refresh()
                        }
                        is ApiClient.ApiResult.Failure -> snackbar.showSnackbar(r.message)
                    }
                }
            }
        )
    }
}

@Composable
fun FolderRow(folder: CloudFolder, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), cornerRadius = 18.dp) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(AccentBlueSoft),
                contentAlignment = Alignment.Center
            ) { Text("📁", fontSize = 20.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(folder.name, style = MaterialTheme.typography.titleSmall, color = InkBlack, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(folder.createdAt, style = MaterialTheme.typography.bodySmall, color = InkGray)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = InkGrayLight)
        }
    }
}

@Composable
fun FileRow(file: CloudFile, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), cornerRadius = 18.dp) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(AccentBlueSoft),
                contentAlignment = Alignment.Center
            ) { Text(Formatters.fileTypeIcon(file.type), fontSize = 20.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(file.name, style = MaterialTheme.typography.titleSmall, color = InkBlack, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${Formatters.size(file.size)} · ${file.createdAt}",
                    style = MaterialTheme.typography.bodySmall, color = InkGray
                )
            }
            Icon(Icons.Filled.MoreVert, null, tint = InkGrayLight)
        }
    }
}

@Composable
fun SheetAction(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge, color = InkBlack)
    }
}

@Composable
fun ShareCreateDialog(
    fileName: String,
    onDismiss: () -> Unit,
    onConfirm: (expireHours: Int, downloadLimit: Int, password: String) -> Unit
) {
    var expireDays by remember { mutableStateOf("7") }
    var dlLimit by remember { mutableStateOf("0") }
    var pwd by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text("创建分享", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("文件：$fileName", style = MaterialTheme.typography.bodySmall, color = InkGray)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = expireDays, onValueChange = { expireDays = it.filter { c -> c.isDigit() } },
                    label = { Text("有效期（天，0=永久）") }, singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentBlue, unfocusedBorderColor = GlassStroke)
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = dlLimit, onValueChange = { dlLimit = it.filter { c -> c.isDigit() } },
                    label = { Text("下载次数限制（0=不限）") }, singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentBlue, unfocusedBorderColor = GlassStroke)
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = pwd, onValueChange = { pwd = it },
                    label = { Text("提取码（可选）") }, singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentBlue, unfocusedBorderColor = GlassStroke)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onConfirm((expireDays.toIntOrNull() ?: 0) * 24, dlLimit.toIntOrNull() ?: 0, pwd.trim())
            }) { Text("创建", color = AccentBlue, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消", color = InkGray) } }
    )
}
