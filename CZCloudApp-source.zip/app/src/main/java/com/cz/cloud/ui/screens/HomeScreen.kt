package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.cz.cloud.api.ApiClient
import com.cz.cloud.data.*
import com.cz.cloud.ui.theme.*
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.sp

/**
 * 首页：存储概览 + 快捷入口
 */
@Composable
fun HomeScreen(nav: NavHostController) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var user by remember { mutableStateOf(SessionManager.cachedUser()) }
    var statsLoading by remember { mutableStateOf(true) }
    var fileCount by remember { mutableStateOf(0) }
    var shareCount by remember { mutableStateOf(0) }
    var downloadTotal by remember { mutableStateOf(0) }

    suspend fun refresh() {
        statsLoading = true
        // 文件统计
        when (val r = CloudRepository.get().listFiles(0)) {
            is ApiClient.ApiResult.Success -> {
                val d = r.json.optJSONObject("data") ?: return
                fileCount = d.optJSONArray("files")?.length() ?: 0
            }
            else -> {}
        }
        // 分享统计
        when (val r = CloudRepository.get().listShares()) {
            is ApiClient.ApiResult.Success -> shareCount = CloudRepository.dataArray(r.json).length()
            else -> {}
        }
        statsLoading = false
    }

    LaunchedEffect(Unit) { refresh() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(12.dp))

        // 欢迎区
        Text(
            "你好，${user?.nickname ?: "用户"}",
            style = MaterialTheme.typography.headlineMedium,
            color = InkBlack
        )
        Text(
            "欢迎回来，这是你的文件概览",
            style = MaterialTheme.typography.bodyMedium,
            color = InkGray
        )

        Spacer(Modifier.height(20.dp))

        // 存储卡片
        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("存储空间", style = MaterialTheme.typography.titleMedium, color = InkBlack)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${Formatters.size(user?.storageUsed ?: 0)} / ${Formatters.size(user?.storageLimit ?: 0)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = InkGray
                    )
                }
                Spacer(Modifier.height(14.dp))
                // 进度条
                val percent = if ((user?.storageLimit ?: 0) > 0)
                    ((user?.storageUsed ?: 0) * 100 / (user?.storageLimit ?: 1)).toInt().coerceIn(0, 100) else 0
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(GlassStroke)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(percent / 100f)
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(AccentBlue)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text("已使用 $percent%", style = MaterialTheme.typography.bodySmall, color = InkGray)
            }
        }

        Spacer(Modifier.height(16.dp))

        // 统计卡片 2x2
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(Modifier.weight(1f), "文件总数", fileCount.toString(), "📁")
            StatCard(Modifier.weight(1f), "下载次数", downloadTotal.toString(), "⬇")
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(Modifier.weight(1f), "分享数量", shareCount.toString(), "🔗")
            StatCard(Modifier.weight(1f), "VIP 等级", "V${user?.vipLevel ?: 0}", "✨")
        }

        Spacer(Modifier.height(24.dp))

        Text("快捷操作", style = MaterialTheme.typography.titleMedium, color = InkBlack)
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction(Modifier.weight(1f), "上传文件", "⬆", AccentBlue) {
                nav.navigate("upload/0")
            }
            QuickAction(Modifier.weight(1f), "全部文件", "📂", SuccessGreen) {
                nav.navigate("files")
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction(Modifier.weight(1f), "我的分享", "🔗", WarnOrange) {
                nav.navigate("shares")
            }
            QuickAction(Modifier.weight(1f), "回收站", "🗑", DangerRed) {
                nav.navigate("recycle")
            }
        }
    }
}

@Composable
fun StatCard(modifier: Modifier, label: String, value: String, emoji: String) {
    GlassCard(modifier = modifier, cornerRadius = 20.dp) {
        Column(Modifier.padding(16.dp)) {
            Text(emoji, fontSize = 24.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, color = InkBlack)
            Text(label, style = MaterialTheme.typography.bodySmall, color = InkGray)
        }
    }
}

@Composable
fun QuickAction(modifier: Modifier, label: String, emoji: String, color: Color, onClick: () -> Unit) {
    GlassCard(modifier = modifier, cornerRadius = 20.dp) {
        Row(
            modifier = Modifier
                .clickable(onClick = onClick)
            .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Text(emoji, fontSize = 18.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(label, style = MaterialTheme.typography.titleSmall, color = InkBlack)
        }
    }
}
