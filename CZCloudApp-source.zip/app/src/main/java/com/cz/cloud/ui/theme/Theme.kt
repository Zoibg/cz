package com.cz.cloud.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ============ iOS 纯白液态玻璃 配色 ============
val GlassWhite = Color(0xFFFFFFFF)
val GlassWhiteSoft = Color(0xF7FFFFFF)     // 半透明玻璃卡片
val GlassStroke = Color(0x1F3C3C43)        // 玻璃描边（黑色 12%）
val GlassShadow = Color(0x14000000)        // 柔和阴影
val GlassBlurBg = Color(0xE6F5F6F8)        // 毛玻璃底色
val InkBlack = Color(0xFF1C1C1E)           // 主文本
val InkGray = Color(0xFF8A8A8E)            // 次要文本
val InkGrayLight = Color(0xFFC7C7CC)       // 占位符
val AccentBlue = Color(0xFF0A84FF)         // iOS 系统蓝
val AccentBlueSoft = Color(0x1F0A84FF)     // 蓝色 12% 透明
val DangerRed = Color(0xFFFF3B30)          // iOS 红
val SuccessGreen = Color(0xFF30D158)       // iOS 绿
val WarnOrange = Color(0xFFFF9F0A)         // iOS 橙

private val LightColors = lightColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = AccentBlueSoft,
    onPrimaryContainer = AccentBlue,
    secondary = InkGray,
    background = GlassBlurBg,
    onBackground = InkBlack,
    surface = GlassWhite,
    onSurface = InkBlack,
    surfaceVariant = Color(0xFFF2F2F7),
    onSurfaceVariant = InkGray,
    error = DangerRed,
    outline = GlassStroke
)

private val DarkColors = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0x330A84FF),
    onPrimaryContainer = Color(0xFF64B5FF),
    secondary = Color(0xFF98989F),
    background = Color(0xFF000000),
    onBackground = Color.White,
    surface = Color(0xFF1C1C1E),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFF98989F),
    error = DangerRed,
    outline = Color(0x33FFFFFF)
)

val AppTypography = Typography(
    displayLarge = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp),
    displayMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    headlineLarge = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Normal, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Normal, lineHeight = 16.sp),
    labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
)

@Composable
fun CZCloudTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
