package com.cz.cloud.data

import com.cz.cloud.api.ApiClient
import com.cz.cloud.api.ApiClient.ApiResult
import org.json.JSONArray
import org.json.JSONObject

/**
 * 业务仓库层：封装 MXH 网盘系统的全部接口调用
 * 服务端协议参考：MXH 网盘系统 1.8.0 源码
 */
class CloudRepository {

    // ==================== 认证 ====================

    /** 账号密码登录 */
    fun login(account: String, password: String, remember: Boolean, sliderTicket: String): ApiResult {
        val p = mutableMapOf(
            "action" to "login",
            "account" to account,
            "password" to password,
            "remember" to if (remember) "1" else "0"
        )
        if (sliderTicket.isNotEmpty()) p["slider_ticket"] = sliderTicket
        return ApiClient.postForm("/api/auth.php", p)
    }

    /** 验证码登录（邮箱） */
    fun codeLogin(email: String, emailCode: String, remember: Boolean): ApiResult =
        ApiClient.postForm("/api/auth.php", mapOf(
            "action" to "code_login",
            "email" to email,
            "email_code" to emailCode,
            "remember" to if (remember) "1" else "0"
        ))

    /** 发送邮箱验证码 */
    fun sendCode(email: String, scene: String): ApiResult =
        ApiClient.postForm("/api/auth.php", mapOf("action" to "send_code", "email" to email, "scene" to scene))

    /** 注册 */
    fun register(email: String, username: String, password: String, emailCode: String): ApiResult =
        ApiClient.postForm("/api/auth.php", mapOf(
            "action" to "register",
            "email" to email,
            "username" to username,
            "password" to password,
            "email_code" to emailCode,
            "agree" to "1",
            "nickname" to username
        ))

    /** 重置密码 */
    fun resetPassword(email: String, code: String, newPassword: String): ApiResult =
        ApiClient.postForm("/api/auth.php", mapOf(
            "action" to "reset_password",
            "email" to email,
            "code" to code,
            "password" to newPassword
        ))

    // ==================== 文件管理 ====================

    /** 列出目录内容 */
    fun listFiles(folderId: Int = 0): ApiResult =
        ApiClient.getJson("/api/files.php?action=list&folder_id=$folderId")

    /** 重命名文件 */
    fun renameFile(id: Int, name: String): ApiResult =
        ApiClient.postForm("/api/files.php", mapOf("action" to "rename", "id" to id.toString(), "name" to name))

    /** 移动文件 */
    fun moveFile(id: Int, folderId: Int): ApiResult =
        ApiClient.postForm("/api/files.php", mapOf("action" to "move", "id" to id.toString(), "folder_id" to folderId.toString()))

    /** 删除文件（进回收站） */
    fun deleteFile(id: Int): ApiResult =
        ApiClient.postForm("/api/files.php", mapOf("action" to "delete", "id" to id.toString()))

    /** 创建文件夹 */
    fun createFolder(name: String, parentId: Int = 0): ApiResult =
        ApiClient.postForm("/api/folders.php", mapOf("action" to "create", "name" to name, "parent_id" to parentId.toString()))

    /** 重命名文件夹 */
    fun renameFolder(id: Int, name: String): ApiResult =
        ApiClient.postForm("/api/folders.php", mapOf("action" to "rename", "id" to id.toString(), "name" to name))

    /** 删除文件夹 */
    fun deleteFolder(id: Int): ApiResult =
        ApiClient.postForm("/api/folders.php", mapOf("action" to "delete", "id" to id.toString()))

    /** 获取文件夹树（用于移动文件选择目标） */
    fun folderTree(): ApiResult = ApiClient.getJson("/api/folders.php?action=tree")

    // ==================== 分享 ====================

    fun listShares(): ApiResult =
        ApiClient.postForm("/api/shares.php", mapOf("action" to "list"))

    fun createShare(
        fileId: Int, shareCode: String = "", expireHours: Int = 0,
        downloadLimit: Int = 0, password: String = "", sharePrefix: String = ""
    ): ApiResult {
        val p = mutableMapOf(
            "action" to "create", "file_id" to fileId.toString(),
            "expire_hours" to expireHours.toString(),
            "download_limit" to downloadLimit.toString()
        )
        if (shareCode.isNotEmpty()) p["share_code"] = shareCode
        if (password.isNotEmpty()) p["password"] = password
        if (sharePrefix.isNotEmpty()) p["share_prefix"] = sharePrefix
        return ApiClient.postForm("/api/shares.php", p)
    }

    fun deleteShare(id: Int): ApiResult =
        ApiClient.postForm("/api/shares.php", mapOf("action" to "delete", "id" to id.toString()))

    /** 回收站列表 */
    fun recycleList(): ApiResult = ApiClient.getJson("/api/recycle.php?action=list")

    /** 恢复回收站文件 */
    fun recycleRestore(id: Int): ApiResult =
        ApiClient.postForm("/api/recycle.php", mapOf("action" to "restore", "id" to id.toString()))

    /** 彻底删除回收站文件 */
    fun recycleDelete(id: Int): ApiResult =
        ApiClient.postForm("/api/recycle.php", mapOf("action" to "delete", "id" to id.toString()))

    /** 清空回收站 */
    fun recycleClear(): ApiResult =
        ApiClient.postForm("/api/recycle.php", mapOf("action" to "clear"))

    // ==================== 分片上传 ====================

    fun uploadInit(fileName: String, size: Long, chunks: Int, chunkSize: Int, folderId: Int): ApiResult =
        ApiClient.postForm("/api/upload_chunk.php", mapOf(
            "action" to "init",
            "filename" to fileName,
            "size" to size.toString(),
            "chunks" to chunks.toString(),
            "chunk_size" to chunkSize.toString(),
            "folder_id" to folderId.toString()
        ))

    fun uploadMerge(uploadId: String): ApiResult =
        ApiClient.postForm("/api/upload_chunk.php", mapOf("action" to "merge", "upload_id" to uploadId))

    companion object {
        @Volatile private var instance: CloudRepository? = null
        fun get(): CloudRepository = instance ?: synchronized(this) {
            instance ?: CloudRepository().also { instance = it }
        }

        fun dataArray(json: JSONObject): JSONArray = ApiClient.dataArray(json)

        fun formatSize(bytes: Long): String = Formatters.size(bytes)
    }
}
