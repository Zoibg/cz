package com.cz.cloud.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.cz.cloud.data.SessionManager
import com.cz.cloud.ui.theme.*
import androidx.compose.foundation.clickable
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(nav: NavHostController) {
    val user = SessionManager.cachedUser()
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text("我的", style = MaterialTheme.typography.headlineMedium, color = InkBlack)
        Spacer(Modifier.height(20.dp))

        // 用户卡片
        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(64.dp).clip(CircleShape).background(AccentBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        (user?.nickname ?: "U").take(1).uppercase(),
                        color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(user?.nickname ?: "用户", style = MaterialTheme.typography.titleLarge, color = InkBlack)
                    Text(user?.email ?: "", style = MaterialTheme.typography.bodySmall, color = InkGray)
                    Spacer(Modifier.height(4.dp))
                    if ((user?.vipLevel ?: 0) > 0) {
                        Text("VIP${user.vipLevel} · 余额 ¥${"%.2f".format(user.balance)}",
                             color = WarnOrange, style = MaterialTheme.typography.labelMedium)
                    } else {
                        Text("余额 ¥${"%.2f".format(user?.balance ?: 0.0)}",
                             color = InkGray, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 存储信息卡
        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
            Column(Modifier.padding(18.dp)) {
                Row {
                    Text("存储空间", style = MaterialTheme.typography.titleSmall, color = InkBlack)
                    Spacer(Modifier.weight(1f))
                    Text(
                        com.cz.cloud.data.Formatters.size(user?.storageUsed ?: 0) + " / " + com.cz.cloud.data.Formatters.size(user?.storageLimit ?: 0),
                        style = MaterialTheme.typography.labelMedium, color = InkGray
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // 退出登录
        GlassCard(modifier = Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().clickable {
                    scope.launch {
                        SessionManager.clearSession()
                        android.os.Process.killProcess(android.os.Process.myPid())
                    }
                }.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Logout, null, tint = DangerRed, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(14.dp))
                Text("退出登录", style = MaterialTheme.typography.bodyLarge, color = DangerRed)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "CZ云盘 · MXH 网盘系统客户端",
            style = MaterialTheme.typography.bodySmall,
            color = InkGrayLight,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
