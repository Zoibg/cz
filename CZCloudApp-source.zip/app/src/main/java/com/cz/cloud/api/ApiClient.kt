package com.cz.cloud.api

import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * CZ云盘 API 客户端
 * 服务端：MXH 网盘系统（PHP + Session 认证）
 * 认证方式：PHPSESSID Cookie（OkHttp CookieJar 自动维护）
 */
object ApiClient {

    const val BASE_URL = "https://cz.xcor.top"
    val FORM = "application/x-www-form-urlencoded; charset=utf-8".toMediaType()

    private val cookieJar = object : CookieJar {
        private val store = ConcurrentHashMap<String, MutableList<Cookie>>()
        override fun loadForRequest(url: HttpUrl): List<Cookie> = synchronized(store) {
            store[url.host] ?: emptyList()
        }
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) = synchronized(store) {
            val list = store.getOrPut(url.host) { mutableListOf() }
            for (nc in cookies) {
                list.removeAll { it.name == nc.name }
                list.add(nc)
            }
        }
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .cookieJar(cookieJar)
        .build()

    sealed class ApiResult {
        data class Success(val json: JSONObject) : ApiResult()
        data class Failure(val message: String) : ApiResult()
    }

    private fun parse(raw: String): ApiResult {
        return try {
            val json = JSONObject(raw)
            if (json.optBoolean("success", false)) ApiResult.Success(json)
            else ApiResult.Failure(json.optString("message", "操作失败"))
        } catch (e: Exception) {
            ApiResult.Failure("响应解析失败：${raw.take(120)}")
        }
    }

    /** 通用 POST 表单请求 */
    fun postForm(path: String, params: Map<String, String>): ApiResult {
        return try {
            val body = params.entries.joinToString("&") {
                "${java.net.URLEncoder.encode(it.key, "UTF-8")}=${java.net.URLEncoder.encode(it.value, "UTF-8")}"
            }.toRequestBody(FORM)
            val req = Request.Builder()
                .url(BASE_URL + path)
                .post(body)
                .header("Referer", "$BASE_URL/")
                .header("X-Requested-With", "XMLHttpRequest")
                .build()
            parse(client.newCall(req).execute().use { it.body?.string() ?: "" })
        } catch (e: IOException) {
            ApiResult.Failure("网络错误：${e.message ?: "连接失败"}")
        } catch (e: Exception) {
            ApiResult.Failure("请求失败：${e.message ?: "未知错误"}")
        }
    }

    /** 通用 GET 请求（返回 JSON 的接口用） */
    fun getJson(path: String): ApiResult {
        return try {
            val req = Request.Builder()
                .url(BASE_URL + path)
                .header("Referer", "$BASE_URL/")
                .header("X-Requested-With", "XMLHttpRequest")
                .build()
            parse(client.newCall(req).execute().use { it.body?.string() ?: "" })
        } catch (e: IOException) {
            ApiResult.Failure("网络错误：${e.message ?: "连接失败"}")
        } catch (e: Exception) {
            ApiResult.Failure("请求失败：${e.message ?: "未知错误"}")
        }
    }

    /** 获取滑块验证码 puzzle（登录人机验证） */
    fun sliderPuzzle(): ApiResult = postForm("/api/slider.php", mapOf("action" to "puzzle"))

    /** 校验滑块，返回 ticket */
    fun sliderCheck(token: String, guess: Int, elapsed: Long, trace: String): ApiResult =
        postForm("/api/slider.php", mapOf(
            "action" to "check", "token" to token, "guess" to guess.toString(),
            "elapsed" to elapsed.toString(), "trace" to trace
        ))

    fun clearCookies() {
        val url = BASE_URL.toHttpUrl()
        cookieJar.saveFromResponse(url, emptyList())
    }

    /** 恢复持久化的 Cookie（App 启动时调用） */
    fun restoreCookies(cookies: List<Cookie>) {
        if (cookies.isEmpty()) return
        val url = BASE_URL.toHttpUrl()
        cookieJar.saveFromResponse(url, cookies)
    }

    /** 导出当前会话 Cookie（用于持久化） */
    fun exportCookies(): List<Cookie> {
        val url = BASE_URL.toHttpUrl()
        return cookieJar.loadForRequest(url)
    }

    /** 分片上传 - 单分片 */
    fun uploadChunk(
        uploadId: String, index: Int, offset: Long, chunkFile: File
    ): ApiResult {
        return try {
            val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("action", "chunk")
                .addFormDataPart("upload_id", uploadId)
                .addFormDataPart("chunk", index.toString())
                .addFormDataPart("offset", offset.toString())
                .addFormDataPart("file", chunkFile.name, chunkFile.asRequestBody("application/octet-stream".toMediaType()))
            val req = Request.Builder()
                .url("$BASE_URL/api/upload_chunk.php")
                .post(mb.build())
                .build()
            parse(client.newCall(req).execute().use { it.body?.string() ?: "" })
        } catch (e: IOException) {
            ApiResult.Failure("分片上传失败：${e.message ?: "网络中断"}")
        }
    }

    companion object {
        /** 解析 data 字段为数组 */
        fun dataArray(json: JSONObject): JSONArray {
            val d = json.opt("data")
            return when (d) {
                is JSONArray -> d
                is JSONObject -> JSONArray().put(d)
                else -> JSONArray()
            }
        }
    }
}
