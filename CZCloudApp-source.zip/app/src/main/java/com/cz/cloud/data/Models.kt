package com.cz.cloud.data

import org.json.JSONObject

data class CloudFile(
    val id: Int,
    val name: String,
    val size: Long,
    val type: String,          // image / video / audio / document / archive / other
    val mime: String,
    val downloadCount: Int,
    val createdAt: String,
    val downloadUrl: String,
    val viewUrl: String
) {
    companion object {
        fun fromJson(o: JSONObject) = CloudFile(
            id = o.optInt("id"),
            name = o.optString("original_name"),
            size = o.optLong("file_size"),
            type = o.optString("file_type", "other"),
            mime = o.optString("mime_type"),
            downloadCount = o.optInt("download_count"),
            createdAt = o.optString("created_fmt").ifEmpty { o.optString("created_at") },
            downloadUrl = o.optString("download_url"),
            viewUrl = o.optString("view_url")
        )
    }
}

data class CloudFolder(
    val id: Int,
    val name: String,
    val createdAt: String
) {
    companion object {
        fun fromJson(o: JSONObject) = CloudFolder(
            id = o.optInt("id"),
            name = o.optString("name"),
            createdAt = o.optString("created_fmt").ifEmpty { o.optString("created_at") }
        )
    }
}

data class CloudShare(
    val id: Int,
    val fileId: Int,
    val fileName: String,
    val fileSize: Long,
    val fileType: String,
    val shareUrl: String,
    val shareCode: String,
    val password: String,
    val expireHours: Int,
    val downloadLimit: Int,
    val downloadCount: Int,
    val price: Double,
    val status: Int,
    val createdAt: String
) {
    companion object {
        fun fromJson(o: JSONObject) = CloudShare(
            id = o.optInt("id"),
            fileId = o.optInt("file_id"),
            fileName = o.optString("original_name").ifEmpty { "（文件已删除）" },
            fileSize = o.optLong("file_size"),
            fileType = o.optString("file_type"),
            shareUrl = o.optString("share_url"),
            shareCode = o.optString("share_code"),
            password = o.optString("password"),
            expireHours = o.optInt("expire_hours"),
            downloadLimit = o.optInt("download_limit"),
            downloadCount = o.optInt("download_count"),
            price = o.optDouble("price", 0.0),
            status = o.optInt("status", 1),
            createdAt = o.optString("created_at")
        )
    }
}

data class RecycleItem(
    val id: Int,
    val name: String,
    val size: Long,
    val type: String,
    val deletedAt: String,
    val restorable: Boolean
) {
    companion object {
        fun fromJson(o: JSONObject) = RecycleItem(
            id = o.optInt("id"),
            name = o.optString("original_name"),
            size = o.optLong("file_size"),
            type = o.optString("file_type", "document"),
            deletedAt = o.optString("deleted_at"),
            restorable = o.optBoolean("restorable")
        )
    }
}

data class UserInfo(
    val id: Int,
    val username: String,
    val email: String,
    val nickname: String,
    val avatar: String,
    val storageUsed: Long,
    val storageLimit: Long,
    val vipLevel: Int,
    val vipExpire: String,
    val balance: Double
) {
    companion object {
        fun fromJson(o: JSONObject) = UserInfo(
            id = o.optInt("id"),
            username = o.optString("username"),
            email = o.optString("email"),
            nickname = o.optString("nickname").ifEmpty { o.optString("username") },
            avatar = o.optString("avatar"),
            storageUsed = o.optLong("storage_used"),
            storageLimit = o.optLong("storage_limit"),
            vipLevel = o.optInt("vip_level"),
            vipExpire = o.optString("vip_expire"),
            balance = o.optDouble("balance", 0.0)
        )
    }
}

object Formatters {
    fun size(bytes: Long): String = when {
        bytes >= 1_073_741_824 -> String.format("%.2f GB", bytes / 1_073_741_824.0)
        bytes >= 1_048_576 -> String.format("%.2f MB", bytes / 1_048_576.0)
        bytes >= 1024 -> String.format("%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    fun fileTypeIcon(type: String): String = when (type) {
        "folder" -> "📁"
        "image" -> "🖼️"
        "video" -> "🎬"
        "audio" -> "🎵"
        "document" -> "📄"
        "archive" -> "📦"
        else -> "📎"
    }
}
