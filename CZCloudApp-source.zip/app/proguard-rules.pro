# CZ Cloud App
-keep class com.cz.cloud.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
